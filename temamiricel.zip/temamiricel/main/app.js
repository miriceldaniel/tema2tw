function addTokens(input, tokens){
// CERINTA 1 
    if (typeof input !== 'string')
{
    throw Error('Invalid input')
}

// CERINTA 2
else if(input.length<6)
{
    throw Error('Input should have at least 6 characters')
}

// CERINTA 3
for(var i =0;i<tokens.length;i++)
{
    if(typeof((tokens[i].tokenName))!=='string')
    throw Error('Invalid array format')
}

// CERINTA 4
if(input.includes('...')!=true) return input;

// CERINTA 5
for(let i=0;i<tokens.length;i++)
{
    let a=tokens[i]["tokenName"]
    let b="${"+a+"}"
    let c="..."
    let position=input.indexOf('...')
    if(position!==-1){
        input=input.replace(c,b)
    }
}
    return input;
}

const app = {
    addTokens: addTokens
}
module.exports = app;